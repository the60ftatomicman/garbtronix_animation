# ---------- References
# --- https://stackoverflow.com/questions/38153754/can-you-fit-multiple-buttons-in-one-grid-cell-in-tkinter
# --- https://bytes.com/topic/python/answers/935717-tkinter-text-widget-check-if-text-edited
# ---------- Imports
# ----- Internal Libs
from os import scandir,mkdir,remove,path
from datetime import datetime
from re import compile, match
from math import floor
import tkinter as tk
# ----- External Libs
from PIL import Image,ImageTk,ImageDraw,ImageFont # Since Python 3, need to use external Pillow
from cv2 import VideoWriter,VideoWriter_fourcc
from numpy import array as numpy_array

# ---------- Initialize
window = tk.Tk()
#strAniFile     = "C:\\Program Files (x86)\\Apache Software Foundation\\Apache2.2\\htdocs\\animation\\discord_junk\\chapter6.txt"
strAniFile     = "C:\\Program Files (x86)\\Apache Software Foundation\\Apache2.2\\htdocs\\animation\\demo_test.txt"
#strAniFile      = "C:\\Program Files (x86)\\Apache Software Foundation\\Apache2.2\\htdocs\\animation\\tron.txt"
dirScratch     = "./scratch"
blnScanningDir = False
blnSavingGif   = False
blnRunLoop     = tk.IntVar()
idxDrawing     = 0
#
blnCaptureLine     = False
regexFrameEnd      = compile('^(\*\*)$')
regexFrameStart    = compile('^(\*)$')
regexHasFrameCount = compile('^0,[0-9]{1,}$')
idxFrame           = -1
lstFrames          = []
intMaxChars_Width  = 0
intMaxChars_Height = 0
time_LastModified  = 0
# ---------- Compile Components
renderFont = ImageFont.truetype("/fonts/lucon.ttf",encoding='unic',size=14)
# ----- Header
frmControls  = tk.Frame(window)
frmTextboxes = tk.Frame(frmControls)
frmButtons   = tk.Frame(frmControls)
# - Run Loop Checkbox
chkRunLoop = tk.Checkbutton(frmControls, text='Run Loop',variable=blnRunLoop, onvalue=1, offvalue=0)
chkRunLoop.grid(row=0, column=0)
# - Width Control
tkWidth  = tk.StringVar()                         # -- stringvar
lblWidth = tk.Label(frmTextboxes,text="W:")       # --- Label
lblWidth.grid(row=0, column=0)
txtWidth = tk.Entry(frmTextboxes,width=5,textvariable=tkWidth)         # --- Textbox
txtWidth.grid(row=0, column=1)

# - Height Control
tkHeight  = tk.StringVar()                         # -- stringvar
tkHeight.set("")
lblHeight = tk.Label(frmTextboxes,text="H:")       # --- Label
lblHeight.grid(row=0, column=2)
txtHeight = tk.Entry(frmTextboxes,width=5,textvariable=tkHeight) # --- Textbox
txtHeight.grid(row=0, column=3)
#tkHeight.trace("w", text_changed)
# - FPS (Speed) Control
lblFPS = tk.Label(frmTextboxes,text="FPS") # --- Label
lblFPS.grid(row=0, column=4)
txtFPS = tk.Spinbox(frmTextboxes,width=5,values=[24,18,15,12,6,1,0.5,0.25,0.1]) # --- Selection Box
txtFPS.grid(row=0, column=5)

# - Resize Button
btnResize = tk.Button(frmButtons, text='Resize')
btnResize.grid(row=0, column=0,padx=2)
# - Previous Button
btnPrevious = tk.Button(frmButtons, text='Previous')
btnPrevious.grid(row=0, column=1,padx=2)
# - Next Button
btnNext = tk.Button(frmButtons, text='Next')
btnNext.grid(row=0, column=2,padx=2)
# - Save Button
btnSave = tk.Button(frmButtons, text='Save')
btnSave.grid(row=0, column=3,padx=2)

# - Img
picDrawing = tk.Label(frmControls, width=512, height=256)
picDrawing.grid(row=0, column=1,columnspan=2)

# -- build it all together
frmControls.grid(row=0,column=0)
frmTextboxes.grid(row=1,column=0)
frmButtons.grid(row=2,column=0)

# ---------- Methods
def checkAnimationFileUpdates():
    global time_LastModified
    time_currentModified = path.getmtime(strAniFile)
    print("[%d] ? [%d] " %(time_currentModified,time_LastModified))
    if(time_currentModified > time_LastModified):
        time_LastModified = time_currentModified
        return True
    else:
        return False

def parseAnimationFile():
    global blnCaptureLine,regexFrameEnd,regexFrameStart,idxFrame,lstFrames,time_LastModified
    if (blnScanningDir == False and blnSavingGif == False):
        lstFrames=[]
        idxFrame=-1
        blnCopieCountLine=True
        intCopies=0
        time_LastModified = path.getmtime(strAniFile)
        with open(strAniFile, mode='r',encoding='utf-8') as fileData:
            lines = fileData.readlines()  # list containing lines of file
            for line in lines:
                if line:
                    if(blnCopieCountLine):
                        if(regexHasFrameCount.match(line)):
                            intCopies = int(line.split(',')[1])
                        blnCopieCountLine=False
                    if(regexFrameEnd.match(line)):
                        blnCaptureLine = False
                        blnCopieCountLine = True
                        for copy in range(intCopies):
                            if copy > 0:
                                lstFrames.append([])
                                lstFrames[idxFrame+copy] = lstFrames[idxFrame]
                        idxFrame=len(lstFrames)-1
                        intCopies=0
                    if(blnCaptureLine):
                        #print(line)
                        lstFrames[idxFrame].append(line)
                    if(regexFrameStart.match(line)):
                        blnCaptureLine = True
                        idxFrame      += 1
                        lstFrames.append([])

def getWidthAndHeight():
    global lstFrames,intMaxChars_Width,intMaxChars_Height,tkWidth,tkHeight
    intMaxChars_Height = 0
    intMaxChars_Width = 0
    for frame in lstFrames:
        intMaxChars_Height = len(frame) if len(frame) > intMaxChars_Height else intMaxChars_Height
        for line in frame:
            intMaxChars_Width = len(line) if len(line) > intMaxChars_Width else intMaxChars_Width

    intMaxChars_Height *= renderFont.font.height
    intMaxChars_Width  *= floor(renderFont.font.height/2)+1#renderFont.font.getsize("A")[0][0]-1
    #
    tkWidth.set(str(intMaxChars_Width))
    #
    tkHeight.set(str(intMaxChars_Height))

def updateFileLists():
    global lstDrawing,blnSavingGif,blnScanningDir
    if (blnSavingGif == False):
        blnScanningDir = True
        lstDrawing = None # hopefully clears memory better
        lstDrawing = []
        for entry in scandir(".\scratch"):
            if (entry.path.endswith(".jpg")
                or entry.path.endswith(".png")) and entry.is_file():
                print("Found Frame: [%s]" % (entry.path))
                frameNum = int(entry.name[5:entry.name.find(".png")])
                if(len(lstDrawing) < frameNum):
                    lstDrawing = lstDrawing + [None] * (frameNum-len(lstDrawing))
                lstDrawing[frameNum-1] = entry.path
        lstDrawing = list(filter((None).__ne__, lstDrawing))

        blnScanningDir = False
        print("Frame Count: [%d]" % (len(lstDrawing)))
    else:
        print("Could not load list, currently saving")
    #
    #window.after(10000, updateFileLists)

def updateIndex(idx,lst,diff):
    newIdx = idx+diff
    if diff > 0 and newIdx >= len(lst):
        newIdx = 0
    if(diff < 0 and  newIdx < 0):
        newIdx = len(lst)-1
    print("Index was: %d is now: %d" % (idx,newIdx))
    return newIdx

def updateImages(picDraw):
    global idxDrawing,lstDrawing

    print("Getting Frame Image [%d] [%s]" % (idxDrawing,lstDrawing[idxDrawing]))
    imgDraw = ImageTk.PhotoImage(
        Image.open(lstDrawing[idxDrawing])
    )
    picDraw.configure(image=imgDraw)
    picDraw.image=imgDraw

def stepImageForward():
    global idxDrawing,lstDrawing
    global picDrawing
    idxDrawing = updateIndex(idxDrawing, lstDrawing, 1)
    updateImages(picDrawing)

def stepImageBack():
    global idxDrawing,lstDrawing
    global picDrawing
    idxDrawing = updateIndex(idxDrawing, lstDrawing, -1)
    updateImages(picDrawing)

def saveGif():
    global lstDrawing,idxReference,blnSavingGif
    images = []
    if (blnScanningDir == False):
        blnSavingGif=True
        for frameImg in lstDrawing:
            images.append(Image.open(frameImg))
        filename = str(datetime.now()).replace(".", "-").replace(":", "-").replace(" ", "_")
        duration  = int(1000/float(txtFPS.get()))
        images[0].save('./' + filename + '.gif', format='GIF', append_images=images[1:], save_all=True,duration=([duration] * len(images)), loop=0)
        saveMp4(filename,images,images[0].width,images[0].height,duration)
        blnSavingGif = False
    else:
        print("Cannot save, currently scanning")

def saveMp4(filename,images,width,height,fps):
    out = VideoWriter(filename+'.mp4',VideoWriter_fourcc(*'MP4V'), fps, (width,height))
    for i in range(len(images)):
        out.write(numpy_array(images[i]))
    out.release()

def updateLoop():
    global picDrawing
    global blnScanningDir
    global blnRunLoop
    nextLoop = 1000
    if(blnScanningDir == False):
        if(blnRunLoop.get() == 1):
            updateImages(picDrawing)
            stepImageForward()
            nextLoop = int(1000/float(txtFPS.get()))
            print("Next frame in: [%d] ms" % (nextLoop))
        else:
            print("Waiting 5 to see to scan [%d] " % (blnRunLoop.get()))
            nextLoop = 5000
            if (checkAnimationFileUpdates()):
                print("Animation File Updated, time to redo!")
                parseAnimationFile()
                getWidthAndHeight()
                createFrameImgs()
                updateFileLists()
                updateImages(picDrawing)
    else:
        print("Be paitent, scanning dirs for more images")

    window.after(nextLoop, updateLoop)

def createFrameImgs():
    global blnScanningDir,renderFont,txtHeight,txtWidth
    blnScanningDir = True
    try:
        mkdir(dirScratch)
    except FileExistsError:
        print("Directory already exist, cleaning it!")
        for filename in scandir(dirScratch):
            remove(filename)
    i = 0
    for frame in lstFrames:
        renderImg = Image.new('RGB', (int(txtWidth.get()), int(txtHeight.get())), color=(255, 255, 255))
        y = 0
        for line in frame:
            ImageDraw.Draw(renderImg).text((0, y*renderFont.font.height),line, fill=(0, 0, 0),font=renderFont)
            y += 1
        i+=1
        renderImg.save(dirScratch + '/Frame' + str(i)+ '.png', format='PNG')
    blnScanningDir = False

def resizeImgs():
    createFrameImgs()
    stepImageForward()
    stepImageBack()
# ---------- Main
if __name__ == '__main__':
    # have to set these AFTER we initalize
    btnResize.configure(command=resizeImgs)
    btnNext.configure(command=stepImageForward)
    btnPrevious.configure(command=stepImageBack)
    btnSave.configure(command=saveGif)

    parseAnimationFile()
    getWidthAndHeight()
    createFrameImgs()

    updateFileLists()
    updateImages(picDrawing)
    window.after(0, updateLoop)
    window.mainloop()




