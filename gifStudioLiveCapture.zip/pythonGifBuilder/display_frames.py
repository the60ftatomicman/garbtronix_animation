from datetime import datetime
from os import scandir
from cv2 import VideoWriter_fourcc
from numpy import array as numpy_array
import tkinter as tk
from PIL import Image,ImageTk
from numpy.core.fromnumeric import size

class DisplayFrame():

    def __init__(self, parentWindow,dirFrames):
        self.export_frames_dir = dirFrames

        # - Controls
        self.parentWindow = parentWindow
        self.parentWindow.title("Preview/Save")
        self.parentWindow.geometry("634x350")
        # - Current Camera Label
        self.picFrame = tk.Label(self.parentWindow, width=512, height=256)
        self.picFrame.pack(pady=10,padx=10)
        #
        # -- Controls Area
        #
        frmControls  = tk.Frame(self.parentWindow)
        # - Run / Stop Animation
        self.lstFrames       = []
        self.intCurrentFrame = tk.IntVar()
        self.intCurrentFrame.set(0)
        self.blnRun         = tk.BooleanVar()
        self.blnRun.set(False)
        self.blnScanningDir = tk.BooleanVar()
        self.blnScanningDir.set(False)
        self.blnSaving = tk.BooleanVar()
        self.blnSaving.set(False)
        chkRunLoop          = tk.Checkbutton(frmControls, text='Run Loop',variable=self.blnRun, onvalue=1, offvalue=0)
        chkRunLoop.grid(row=0, column=0)
        # - FPS (Speed) Control
        self.currentFPS = tk.IntVar()
        self.currentFPS.set(0)
        lblFPS = tk.Label(frmControls,text="FPS") # --- Label
        lblFPS.grid(row=0, column=1)
        self.txtFPS = tk.Spinbox(frmControls,width=5,values=[24,18,15,12,6,1,0.5,0.25,0.1]) # --- Selection Box
        self.txtFPS.grid(row=0, column=2)
        # - Rescan Button
        btnRescan = tk.Button(frmControls, text='Rescan')
        btnRescan.grid(row=1, column=0,padx=2)
        btnRescan.configure(command=self.UpdateFileList)
        # - Previous Button
        btnPrevious = tk.Button(frmControls, text='Previous')
        btnPrevious.grid(row=1, column=1,padx=2)
        btnPrevious.configure(command=self.stepImageBack)
        # - Next Button
        btnNext = tk.Button(frmControls, text='Next')
        btnNext.grid(row=1, column=2,padx=2)
        btnNext.configure(command=self.stepImageForward)
        # - Save Button
        btnSave = tk.Button(frmControls, text='Export')
        btnSave.grid(row=1, column=3,padx=2)
        btnSave.configure(command=self.saveGif)
        #
        # - Pack form thus packing buttons
        #
        frmControls.pack()
        #
        #
        #
        self.UpdateFileList()
        self.UpdateCurrentFrame()

    def stepImageForward(self):
        currentFrame = self.intCurrentFrame.get()
        nextFrame    = currentFrame + 1
        if(nextFrame < len(self.lstFrames)):
            self.intCurrentFrame.set(nextFrame)
        else:
            self.intCurrentFrame.set(0)
        self.UpdateCurrentFrame()

    def stepImageBack(self):
        currentFrame = self.intCurrentFrame.get()
        nextFrame    = currentFrame - 1
        if(nextFrame > 0):
            self.intCurrentFrame.set(nextFrame)
        else:
            self.intCurrentFrame.set(len(self.lstFrames)-1)
        self.UpdateCurrentFrame()

    def UpdateCurrentFrame(self):
        #Update drawings
        if(len(self.lstFrames) > 0):
            print("Getting Frame Image [%d] [%s]" % (self.intCurrentFrame.get(),self.lstFrames[self.intCurrentFrame.get()]))
            imgFrame = ImageTk.PhotoImage(
                Image.open(self.lstFrames[self.intCurrentFrame.get()])
            )
            self.picFrame.configure(image=imgFrame)
            self.picFrame.image=imgFrame

    def UpdateFileList(self):
        if (self.blnRun.get() == False):
            self.blnScanningDir.set(True)
            self.lstFrames = None # hopefully clears memory better
            self.lstFrames = []
            for entry in scandir(self.export_frames_dir):
                if (entry.path.endswith(".png") and entry.path) and entry.is_file():
                    print("Found Frame: [%s]" % (entry.path))
                    self.lstFrames.append(entry.path)
            self.lstFrames = list(filter((None).__ne__, self.lstFrames))
            self.lstFrames.sort()
            self.blnScanningDir.set(False)
            print("Frame Count: [%d]" % (len(self.lstFrames)))
        else:
            print("Could not load list, currently running frames")
        
    def UpdateFrames(self):
        if(self.blnRun.get() and self.blnSaving.get() == False):
            if(self.tick()):
                self.stepImageForward()

    def tick(self):
        self.currentFPS.set(self.currentFPS.get()+1)
        fps = self.txtFPS.get()
        if (fps != ""):
            if(self.currentFPS.get() > int(1000/float(fps))):
                self.currentFPS.set(0)
                return True
        else:
            self.currentFPS.set(0)
        return False
        
    def saveGif(self):
        images = []
        if (self.blnRun.get() == False):
            self.blnSaving.set(True)
            for frameImg in self.lstFrames:
                images.append(Image.open(frameImg))
            filename = str(datetime.now()).replace(".", "-").replace(":", "-").replace(" ", "_")
            duration  = int(1000/float(self.txtFPS.get()))
            images[0].save('./' + filename + '.gif', format='GIF', append_images=images[1:], save_all=True,duration=([duration] * len(images)), loop=0)
            #saveMp4(filename,images,images[0].width,images[0].height,duration)
            self.blnSaving.set(False)
        else:
            print("Cannot save, currently scanning")

    def saveMp4(filename,images,width,height,fps):
        out = VideoWriter_fourcc(filename+'.mp4',VideoWriter_fourcc(*'MP4V'), fps, (width,height))
        for i in range(len(images)):
            out.write(numpy_array(images[i]))
        out.release()    
#Do not want auto scanning...too much to handle ATM. Pressing a button is far better for the time being.
#def checkIfNewImagePresent():
#    global count_Images,dirScratch
#    count_Current = len([name for name in listdir(dirScratch) if path.isfile(path.join(dirScratch, name))])
#    print("[%d] ? [%d] " %(count_Images,count_Current))
#    if(count_Images != count_Current):
#        count_Images = count_Current
#        return True
#    else:
#        return False