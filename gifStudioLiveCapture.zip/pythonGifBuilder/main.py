# ---------- References
# --- https://stackoverflow.com/questions/38153754/can-you-fit-multiple-buttons-in-one-grid-cell-in-tkinter
# --- https://bytes.com/topic/python/answers/935717-tkinter-text-widget-check-if-text-edited
# ---------- Imports
# ----- Internal Libs
from os import listdir,scandir,mkdir,remove,path
from datetime import datetime
from re import compile, match
from math import floor
from time import sleep
# ----- Custom Libs
from display_capture import DisplyCapture
from display_frames import DisplayFrame
# ----- External Libs
import tkinter as tk

# ---------- Initialize
window = tk.Tk()
dirScratch     = "./scratch"
blnScanningDir = False
blnSavingGif   = False
idxDrawing     = 0
#
idxFrame           = -1
lstFrames          = []
count_Images       = 0
# ---------- Compile Components
#renderFont = ImageFont.truetype("./fonts/lucon.ttf",encoding='unic',size=14)
# ----- Header
# - Width Control
#tkWidth  = tk.StringVar()                         # -- stringvar
#lblWidth = tk.Label(frmTextboxes,text="W:")       # --- Label
#lblWidth.grid(row=0, column=0)
#txtWidth = tk.Entry(frmTextboxes,width=5,textvariable=tkWidth)         # --- Textbox
#txtWidth.grid(row=0, column=1)

# - Height Control
#tkHeight  = tk.StringVar()                         # -- stringvar
#tkHeight.set("")
#lblHeight = tk.Label(frmTextboxes,text="H:")       # --- Label
#lblHeight.grid(row=0, column=2)
#txtHeight = tk.Entry(frmTextboxes,width=5,textvariable=tkHeight) # --- Textbox
#txtHeight.grid(row=0, column=3)
#tkHeight.trace("w", text_changed)

# - Resize Button
#btnResize = tk.Button(frmButtons, text='Resize')
#btnResize.grid(row=0, column=0,padx=2)


# ---------- Methods

def getWidthAndHeight():
    global lstFrames,intMaxChars_Width,intMaxChars_Height,tkWidth,tkHeight
    intMaxChars_Height = 0
    intMaxChars_Width = 0
    for frame in lstFrames:
        intMaxChars_Height = len(frame) if len(frame) > intMaxChars_Height else intMaxChars_Height
        for line in frame:
            intMaxChars_Width = len(line) if len(line) > intMaxChars_Width else intMaxChars_Width

    #intMaxChars_Height *= renderFont.font.height
    #intMaxChars_Width  *= floor(renderFont.font.height/2)+1#renderFont.font.getsize("A")[0][0]-1
    #
    tkWidth.set(str(intMaxChars_Width))
    #
    tkHeight.set(str(intMaxChars_Height))


def resizeImgs():
    createFrameImgs()
    stepImageForward()
    stepImageBack()

def updateLoop():
    frame_window.UpdateFrames()
    capture_window.UpdateCamera()
    window.after(1, updateLoop)

# ---------- Main
if __name__ == '__main__':
    frame_window   = DisplayFrame(window,dirScratch)
    capture_window = DisplyCapture(window,dirScratch)
    window.after(0,updateLoop)
    window.mainloop()
