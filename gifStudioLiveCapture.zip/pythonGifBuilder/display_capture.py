from tkinter.constants import NW
from cv2 import VideoWriter,VideoWriter_fourcc,imshow,VideoCapture,cvtColor,COLOR_BGR2RGB
import cv2
from numpy import array as numpy_array
import tkinter as tk
from PIL import Image,ImageTk
from numpy.core.fromnumeric import size
from os.path import exists

class DisplyCapture():

    def __init__(self, parentWindow,dirFrames):
        self.export_frames_dir = dirFrames

        # - Controls
        self.parentWindow = parentWindow
        self.newWindow = tk.Toplevel(self.parentWindow,name="capture")
        self.newWindow.title("Capture")
        self.newWindow.geometry("634x350")

        # - Current Camera Label
        #self.picCamera = tk.Label(self.newWindow, width=512, height=256)
        self.frame_rgb = None
        self.frame_ghost = None
        self.picCamera = tk.Canvas(self.newWindow, width=512, height=256,background="red")
        self.picCamera.pack(pady=10,padx=10)
        
        #
        # -- Controls Area
        #
        self.frmControls  = tk.Frame(self.newWindow)
        # - Run Loop Checkbox
        self.blnRunCapture = tk.BooleanVar()
        self.chkRunLoop = tk.Checkbutton(self.frmControls, text='Start Capture',variable=self.blnRunCapture)
        self.chkRunLoop.grid(row=0, column=0)
        # - Capture Button
        self.btnCapture = tk.Button(self.frmControls, text='Capture')
        self.btnCapture.grid(row=0, column=1)
        self.btnCapture.configure(command=self.SaveCapture)
        # - Frame Count Control
        self.txtFrameNum  = tk.StringVar()                             # -- stringvar
        self.txtFrameNum.set("0")
        self.lblFrameNum  = tk.Label(self.frmControls,text="Frame #:") # --- Label
        self.lblFrameNum.grid(row=0, column=2)
        self.txtFrame = tk.Entry(self.frmControls,width=5,textvariable=self.txtFrameNum)         # --- Textbox
        self.txtFrame.grid(row=0, column=3)
        #
        # - Pack form thus packing buttons
        #
        self.frmControls.pack()
        #
        # - Capture Stream
        #
        self.vid = VideoCapture(0)
        self.UpdateCamera(True)

    def getGhostImage(self):
        prev_num = str(int(self.txtFrameNum.get())-1)
        imgPath  = self.export_frames_dir+"/frame"+prev_num+".png"
        if(exists(imgPath)):
            alpha_img = Image.open(imgPath)
            alpha_channel = Image.new('L',(512,256),128)
            alpha_img.putalpha(alpha_channel)
            self.frame_ghost = ImageTk.PhotoImage(alpha_img)
            return True
        else:
            return False


    def UpdateCamera(self,override=False):
        if(self.blnRunCapture.get() or override):
            ret,frame = self.vid.read()
            corrected_color_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            resized_frame = cv2.resize(corrected_color_frame, (512,256))
            #this has to be "self" as it cannot be garbage collected.
            # See https://www.c-sharpcorner.com/blogs/basics-for-displaying-image-in-tkinter-python
            self.frame_rgb = ImageTk.PhotoImage(
                Image.fromarray(resized_frame)
            )
            #If we run with label
            #self.picCamera.configure(image=frame_rgb)
            #self.picCamera.image=frame_rgb
            #self.picCamera.pack()
            #If we run with Canvas
            self.picCamera.delete("all")
            if(self.frame_rgb is not None):
                self.picCamera.create_image(0,0, anchor=NW, image=self.frame_rgb)
            if(self.getGhostImage() and self.frame_ghost is not None):
                self.picCamera.create_image(0,0, anchor=NW, image=self.frame_ghost)
            

    def SaveCapture(self):
        img = ImageTk.getimage( self.frame_rgb )
        # - for reference to last pic
        #img.save(self.export_frames_dir+"/nonlooping/ghostframe.png", "PNG")
        # - for current frame
        num = self.txtFrameNum.get()
        img.save(self.export_frames_dir+"/frame"+num+".png", "PNG")
        self.txtFrameNum.set(str(int(num)+1))

        
        
        
        
    